/*
 * This file is part of LocalTube.
 *
 * LocalTube is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * LocalTube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with LocalTube. If not, see <https://www.gnu.org/licenses/>.
 */

package com.lexus2026.localtube;

import android.util.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class SeriesIndex {

    private static final String TAG       = "SeriesIndex";
    public  static final String FILE_NAME = ".SIndex.json";

    
    private static final Pattern PARENTHESES = Pattern.compile("\\([^)]*\\)");

    
    private static final Pattern DIGIT_RUN = Pattern.compile("\\d+");

    private final File   seriesDir;   
    private final String seriesName;  
    private List<VideoItem> episodes  = new ArrayList<VideoItem>();

    public SeriesIndex(File seriesDir) {
        this.seriesDir  = seriesDir;
        this.seriesName = seriesDir.getName();
    }

    
    
    

    
    public List<VideoItem> load() {
        File f = new File(seriesDir, FILE_NAME);
        if (!f.exists()) { episodes = new ArrayList<VideoItem>(); return episodes; }
        try {
            byte[] b = readFile(f);
            JSONArray arr = new JSONArray(new String(b, "UTF-8"));
            List<VideoItem> loaded = new ArrayList<VideoItem>();
            for (int i = 0; i < arr.length(); i++) loaded.add(fromJson(arr.getJSONObject(i)));
            episodes = loaded;
        } catch (Exception e) {
            Log.e(TAG, "load failed: " + seriesDir.getAbsolutePath(), e);
            episodes = new ArrayList<VideoItem>();
        }
        return episodes;
    }

    
    public void save() {
        try {
            JSONArray arr = new JSONArray();
            for (VideoItem v : episodes) arr.put(toJson(v));
            File f = new File(seriesDir, FILE_NAME);
            FileWriter w = new FileWriter(f);
            w.write(arr.toString(2));
            w.close();
        } catch (Exception e) {
            Log.e(TAG, "save failed: " + seriesDir.getAbsolutePath(), e);
        }
    }

    
    
    

    
    public boolean scanIncremental(List<File> realVideoFiles,
                                   ChannelIndex.ScanProgressCallback cb) {
        
        Map<String, VideoItem> indexedByPath = new LinkedHashMap<String, VideoItem>();
        for (VideoItem v : episodes) indexedByPath.put(v.path, v);

        Set<String> realPaths = new HashSet<String>();
        for (File f : realVideoFiles) realPaths.add(f.getAbsolutePath());

        boolean changed = false;

        
        Iterator<Map.Entry<String, VideoItem>> it = indexedByPath.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, VideoItem> e = it.next();
            if (!realPaths.contains(e.getKey())) {
                it.remove();
                changed = true;
                Log.d(TAG, "[" + seriesName + "] Removed: " + e.getKey());
            }
        }

        
        int idx = 0, total = realVideoFiles.size();
        for (File f : realVideoFiles) {
            idx++;
            if (!indexedByPath.containsKey(f.getAbsolutePath())) {
                if (cb != null) cb.onProgress(f.getName(), idx, total);
                
                
                VideoItem item = buildMinimalItem(f);
                indexedByPath.put(item.path, item);
                changed = true;
                Log.d(TAG, "[" + seriesName + "] Added: " + f.getName());
            }
        }

        
        List<VideoItem> list = new ArrayList<VideoItem>(indexedByPath.values());
        assignEpisodeNumbers(list);
        Collections.sort(list, new Comparator<VideoItem>() {
				@Override public int compare(VideoItem a, VideoItem b) {
					int ea = a.episode < 0 ? Integer.MAX_VALUE : a.episode;
					int eb = b.episode < 0 ? Integer.MAX_VALUE : b.episode;
					return Integer.compare(ea, eb);
				}
			});
        episodes = list;
        return changed;
    }

    
    
    

    
    static void assignEpisodeNumbers(List<VideoItem> items) {
        List<VideoItem> withNumber    = new ArrayList<VideoItem>();
        List<VideoItem> withoutNumber = new ArrayList<VideoItem>();

        for (VideoItem v : items) {
            if (v.episodeManual) {
                
                if (v.episode < 0) v.episode = 0;
                withNumber.add(v);
                continue;
            }
            int num = extractEpisodeNumber(v.fileName != null ? v.fileName : "");
            v.episode = num;
            if (num >= 0) withNumber.add(v);
            else          withoutNumber.add(v);
        }

        
        Collections.sort(withoutNumber, new Comparator<VideoItem>() {
				@Override public int compare(VideoItem a, VideoItem b) {
					return Long.compare(a.dateModified, b.dateModified);
				}
			});

        
        int maxNum = 0;
        for (VideoItem v : withNumber) if (v.episode > maxNum) maxNum = v.episode;

        int seq = maxNum + 1;
        for (VideoItem v : withoutNumber) {
            v.episode = seq++;
        }
    }

    
    static int extractEpisodeNumber(String fileName) {
        if (fileName == null || fileName.isEmpty()) return -1;

        
        String name = fileName;
        int dot = name.lastIndexOf('.');
        if (dot > 0) name = name.substring(0, dot);

        
        name = PARENTHESES.matcher(name).replaceAll(" ");

        
        Matcher m = DIGIT_RUN.matcher(name);
        while (m.find()) {
            int start = m.start();
            int end   = m.end();

            boolean stuckToLetterBefore = start > 0 && Character.isLetter(name.charAt(start - 1));
            boolean stuckToLetterAfter  = end < name.length() && Character.isLetter(name.charAt(end));

            if (stuckToLetterBefore || stuckToLetterAfter) {
                continue; 
            }

            try { return Integer.parseInt(m.group()); }
            catch (NumberFormatException ignored) {}
        }

        return -1;
    }

    
    
    

    public String          getSeriesName() { return seriesName; }
    public File            getSeriesDir()  { return seriesDir; }
    public List<VideoItem> getEpisodes()   { return episodes; }
    public int             getCount()      { return episodes.size(); }

    
    public VideoItem getFirstEpisode() {
        return episodes.isEmpty() ? null : episodes.get(0);
    }

    
    public void mergeVideoItem(VideoItem full) {
        for (int i = 0; i < episodes.size(); i++) {
            if (full.path != null && full.path.equals(episodes.get(i).path)) {
                
                VideoItem old = episodes.get(i);
                full.episode       = old.episode;
                full.episodeManual = old.episodeManual;
                full.tags          = old.tags;
                episodes.set(i, full);
                return;
            }
        }
        
        episodes.add(full);
        assignEpisodeNumbers(episodes);
        resort();
    }

    
    public void resort() {
        Collections.sort(episodes, new Comparator<VideoItem>() {
				@Override public int compare(VideoItem a, VideoItem b) {
					int ea = a.episode < 0 ? Integer.MAX_VALUE : a.episode;
					int eb = b.episode < 0 ? Integer.MAX_VALUE : b.episode;
					return Integer.compare(ea, eb);
				}
			});
    }

    
    
    
    

    private VideoItem buildMinimalItem(File f) {
        VideoItem item  = new VideoItem();
        item.path       = f.getAbsolutePath();
        item.fileName   = f.getName();
        item.fileSize   = f.length();
        item.dateModified = f.lastModified();
        item.type       = VideoItem.TYPE_SERIES;
        item.seriesName = seriesName;

        String base = item.fileName;
        dot: {
            int d = base.lastIndexOf('.');
            if (d > 0) base = base.substring(0, d);
        }
        item.title = base.replace('_', ' ').replace('-', ' ').trim();
        return item;
    }

    
    
    

    private JSONObject toJson(VideoItem v) throws Exception {
        JSONObject o = new JSONObject();
        o.put("id",           v.id           == null ? "" : v.id);
        o.put("path",         v.path         == null ? "" : v.path);
        o.put("title",        v.title        == null ? "" : v.title);
        o.put("fileName",     v.fileName     == null ? "" : v.fileName);
        o.put("channelId",    v.channelId    == null ? "" : v.channelId);
        o.put("episode",      v.episode);
        o.put("episodeManual", v.episodeManual);
        JSONArray tagsArr = new JSONArray();
        if (v.tags != null) for (String t : v.tags) tagsArr.put(t);
        o.put("tags",         tagsArr);
        o.put("seriesName",   seriesName);
        o.put("duration",     v.duration);
        o.put("fileSize",     v.fileSize);
        o.put("width",        v.width);
        o.put("height",       v.height);
        o.put("mimeType",     v.mimeType     == null ? "" : v.mimeType);
        o.put("dateAdded",    v.dateAdded);
        o.put("dateModified", v.dateModified);
        o.put("thumbPath",    v.thumbPath    == null ? "" : v.thumbPath);
        o.put("restorerFile", v.restorerFile == null ? "" : v.restorerFile);
        o.put("playCount",    v.playCount);
        o.put("totalWatchTime", v.totalWatchTime);
        o.put("lastWatched",  v.lastWatched);
        o.put("lastPosition", v.lastPosition);
        o.put("completionRate", v.completionRate);
        o.put("score",        v.score);
        return o;
    }

    private VideoItem fromJson(JSONObject o) throws Exception {
        VideoItem v = new VideoItem();
        v.id           = o.optString("id");
        v.path         = o.optString("path");
        v.title        = o.optString("title");
        v.fileName     = o.optString("fileName");
        v.channelId    = o.optString("channelId");
        v.episode      = o.optInt("episode", -1);
        v.episodeManual = o.optBoolean("episodeManual", false);
        v.tags = new ArrayList<String>();
        JSONArray tagsArr = o.optJSONArray("tags");
        if (tagsArr != null) {
            for (int i = 0; i < tagsArr.length(); i++) {
                String t = tagsArr.optString(i, null);
                if (t != null && !t.isEmpty()) v.tags.add(t);
            }
        }
        v.seriesName   = seriesName;
        v.duration     = o.optLong("duration");
        v.fileSize     = o.optLong("fileSize");
        v.width        = o.optInt("width");
        v.height       = o.optInt("height");
        v.mimeType     = o.optString("mimeType");
        v.dateAdded    = o.optLong("dateAdded");
        v.dateModified = o.optLong("dateModified");
        v.thumbPath    = o.optString("thumbPath");
        if (v.thumbPath != null && v.thumbPath.isEmpty()) v.thumbPath = null;
        v.restorerFile = o.optString("restorerFile");
        if (v.restorerFile != null && v.restorerFile.isEmpty()) v.restorerFile = null;
        v.playCount      = o.optInt("playCount");
        v.totalWatchTime = o.optLong("totalWatchTime");
        v.lastWatched    = o.optLong("lastWatched");
        v.lastPosition   = o.optLong("lastPosition");
        v.completionRate = (float) o.optDouble("completionRate");
        v.score          = (float) o.optDouble("score");
        v.type           = VideoItem.TYPE_SERIES;
        if (v.channelId != null && v.channelId.isEmpty()) v.channelId = null;
        return v;
    }

    
    
    

    private static byte[] readFile(File f) throws IOException {
        FileInputStream fis = new FileInputStream(f);
        byte[] b = new byte[(int) f.length()];
        fis.read(b);
        fis.close();
        return b;
    }
}
